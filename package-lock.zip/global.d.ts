export {};

declare global {
    interface Window {
        GeBrain: {
            // Configuration & System
            getConfig: () => any;
            getSystemPrompt: () => string;
            updateSystemPrompt: (prompt: string) => any;
            appendSystemPrompt: (prompt: string) => any;
            
            // Memory & History
            getConversationHistory: () => any[];
            addMemory: (name: string, content: string) => any;
            
            // File System
            listFiles: () => any[];
            readFile: (path: string) => any;
            writeFile: (path: string, content: string) => any;
            deleteFile: (path: string) => any;
            
            // Tools
            getTools: () => any[];
            registerTool: (def: any, impl: string, auto: boolean) => any;
            removeTool: (name: string) => any;
            toggleTool: (name: string, active: boolean) => any;
            getToolDetails: (name: string) => any;
        };
    }
}