import React, { useEffect, useRef } from 'react';
import { AppConfig, Message, VirtualMemory, UserTool } from '../types';
import { getThread } from '../services/geminiService';
import { normalizePath } from '../utils/fileSystem';

// 根据后缀名简单推断语言
const detectLanguage = (path: string) => {
  if (path.endsWith('.tsx') || path.endsWith('.ts')) return 'typescript';
  if (path.endsWith('.jsx') || path.endsWith('.js')) return 'javascript';
  if (path.endsWith('.css')) return 'css';
  if (path.endsWith('.json')) return 'json';
  if (path.endsWith('.html')) return 'html';
  return 'plaintext';
};

interface GlobalAPIProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  messageMap: Record<string, Message>;
  headId: string | null;
}

export const useGlobalAPI = ({ config, setConfig, messageMap, headId }: GlobalAPIProps) => {
  // Use refs to access latest state without triggering re-registration
  const stateRef = useRef({ config, messageMap, headId });

  useEffect(() => {
    stateRef.current = { config, messageMap, headId };
  }, [config, messageMap, headId]);

  useEffect(() => {
    const api = {
      // --- Configuration & System ---
      getConfig: () => {
        const { config } = stateRef.current;
        return {
          ...config,
          models: config.models.map(m => ({ ...m, apiKey: m.apiKey ? '***' + m.apiKey.slice(-4) : 'unset' }))
        };
      },

      getSystemPrompt: () => stateRef.current.config.systemPrompt,

      updateSystemPrompt: (newPrompt: string) => {
        if (!newPrompt || newPrompt.trim().length === 0) {
          return { success: false, message: "提示词不能为空" };
        }
        if (newPrompt.length > 5000) {
          return { success: false, message: "提示词过长（最大5000字符）" };
        }
        const oldPrompt = stateRef.current.config.systemPrompt;
        setConfig(prev => ({ ...prev, systemPrompt: newPrompt }));
        return { success: true, message: "系统提示词已更新", oldPrompt, newPrompt, length: newPrompt.length };
      },

      appendSystemPrompt: (additional: string) => {
        const current = stateRef.current.config.systemPrompt;
        const newPrompt = `${current}\n\n${additional}`;
        setConfig(prev => ({ ...prev, systemPrompt: newPrompt }));
        return { success: true, message: "系统提示词已追加", length: newPrompt.length };
      },

      // --- Memory & History ---
      getConversationHistory: () => {
        const { messageMap, headId } = stateRef.current;
        return getThread(messageMap, headId);
      },

      addMemory: (name: string, content: string) => {
        const memory: VirtualMemory = {
          id: crypto.randomUUID(),
          name,
          content,
          active: true
        };
        setConfig(prev => ({ ...prev, memories: [...prev.memories, memory] }));
        return { success: true, memory };
      },

      // --- File System (核心重构) ---

      // 1. 列出文件 (提供给 AI 看的摘要)
      listFiles: () => {
        return stateRef.current.config.files.map(f => ({
          path: f.path || f.name, // 兼容旧数据
          size: f.content.length,
          language: f.language
        }));
      },

      // 2. 读取文件 (支持模糊路径匹配)
      readFile: (targetPath: string) => {
        if (!targetPath) return { success: false, message: "Path required" };
        const cleanTarget = normalizePath(targetPath);

        // 查找逻辑：精确匹配 path，或者匹配文件名结尾 (例如 AI 只说 "Button.tsx")
        const file = stateRef.current.config.files.find(f => {
          const currentPath = f.path || f.name;
          const cleanF = normalizePath(currentPath);
          return cleanF === cleanTarget || cleanF.endsWith(`/${cleanTarget}`);
        });

        if (!file) return { success: false, message: `File '${targetPath}' not found` };
        return { success: true, content: file.content, path: file.path || file.name };
      },

      // 3. 写入文件 (自动处理路径和创建)
      writeFile: (targetPath: string, content: string) => {
        if (!targetPath) return { success: false, message: "Path required" };

        const cleanPath = normalizePath(targetPath);
        const fileName = cleanPath.split('/').pop() || cleanPath;
        let action = 'created';

        setConfig(prev => {
          const newFiles = [...prev.files];
          const idx = newFiles.findIndex(f => normalizePath(f.path || f.name) === cleanPath);

          if (idx >= 0) {
            // 更新现有文件
            action = 'updated';
            newFiles[idx] = {
              ...newFiles[idx],
              content,
              path: cleanPath, // Ensure path is up to date
              lastModified: Date.now()
            };
          } else {
            // 创建新文件 (隐式创建目录结构)
            newFiles.push({
              id: crypto.randomUUID(),
              path: cleanPath,
              name: fileName,
              content,
              language: detectLanguage(cleanPath),
              lastModified: Date.now()
            });
          }
          return { ...prev, files: newFiles };
        });
        return { success: true, message: `File '${cleanPath}' ${action}` };
      },

      // 4. 删除文件
      deleteFile: (targetPath: string) => {
        const cleanPath = normalizePath(targetPath);

        // 1. 使用 stateRef 立即检查文件是否存在 (同步操作)
        const exists = stateRef.current.config.files.some(
          f => normalizePath(f.path || f.name) === cleanPath
        );

        if (!exists) {
          return { success: false, message: `File '${cleanPath}' not found` };
        }

        // 2. 如果存在，则执行状态更新
        setConfig(prev => {
          const remaining = prev.files.filter(f => normalizePath(f.path || f.name) !== cleanPath);
          return { ...prev, files: remaining };
        });

        // 3. 立即返回成功 (因为我们知道它在之前的状态里存在，且已经发起了删除)
        return { success: true, message: `File '${cleanPath}' deleted` };
      },


      // --- Tools ---
      getTools: () => {
        return stateRef.current.config.tools.map(t => ({
          name: t.definition?.name || 'Unnamed Tool',
          description: t.definition?.description || '',
          active: t.active,
          autoExecute: t.autoExecute
        }));
      },

      registerTool: (toolDefinition: any, implementation: string, autoExecute: boolean = false) => {
        if (!toolDefinition.name) return { success: false, message: "工具必须包含name属性" };
        const exists = stateRef.current.config.tools.find(t => t.definition?.name === toolDefinition.name);
        if (exists) return { success: false, message: `工具 ${toolDefinition.name} 已存在` };

        const newTool: UserTool = {
          id: crypto.randomUUID(),
          definition: toolDefinition,
          active: true,
          implementation,
          autoExecute
        };
        setConfig(prev => ({ ...prev, tools: [...prev.tools, newTool] }));
        return { success: true, message: `工具 ${toolDefinition.name} 注册成功`, tool: newTool };
      },

      removeTool: (toolName: string) => {
        const currentTools = stateRef.current.config.tools;
        const newTools = currentTools.filter(t => t.definition?.name !== toolName);
        if (newTools.length === currentTools.length) return { success: false, message: `未找到工具 ${toolName}` };
        setConfig(prev => ({ ...prev, tools: newTools }));
        return { success: true, message: `工具 ${toolName} 已删除` };
      },

      toggleTool: (toolName: string, active: boolean) => {
        const idx = stateRef.current.config.tools.findIndex(t => t.definition?.name === toolName);
        if (idx === -1) return { success: false, message: `未找到工具 ${toolName}` };

        setConfig(prev => {
          const tools = [...prev.tools];
          tools[idx] = { ...tools[idx], active };
          return { ...prev, tools };
        });
        return { success: true, message: `工具 ${toolName} 已${active ? '启用' : '禁用'}` };
      },

      getToolDetails: (toolName: string) => {
        const tool = stateRef.current.config.tools.find(t => t.definition?.name === toolName);
        if (!tool) return { success: false, message: `未找到工具 ${toolName}` };
        return { success: true, tool: { ...tool, definition: tool.definition } };
      }
    };

    window.GeBrain = api;

    return () => {
      // @ts-ignore
      delete window.GeBrain;
    };
  }, []); // Run once, depend on refs
};