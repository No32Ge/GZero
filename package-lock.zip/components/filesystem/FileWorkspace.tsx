import React, { useRef, useState, useMemo } from 'react';
import { useFileStore } from '../../stores/useFileStore';
import { useBrain } from '../../contexts/BrainContext';
import { FileExplorer } from './FileExplorer';
import { CodeEditor } from './CodeEditor';
import { normalizePath, optimizeImportedFiles } from '../../utils/fileSystem';
import { extractDependencies, transformToSandpackFiles, detectTemplate } from '../../utils/sandpackUtils';
import { PreviewPanel } from './PreviewPanel';
import { VirtualFile } from '../../types';
import { Icons } from '../Icon';

// @ts-ignore
import JSZip from 'jszip';

// --- 定义标准模板数据 ---
const TEMPLATES = {
    react: [
        {
            path: 'package.json',
            content: JSON.stringify({
                "name": "vite-react-starter",
                "private": true,
                "version": "0.0.0",
                "type": "module",
                "scripts": { "dev": "vite", "build": "vite build", "preview": "vite preview" },
                "dependencies": { "react": "^18.2.0", "react-dom": "^18.2.0", "lucide-react": "^0.263.1" },
                "devDependencies": { "@types/react": "^18.2.15", "@types/react-dom": "^18.2.7", "@vitejs/plugin-react": "^4.0.3", "vite": "^4.4.5" }
            }, null, 2),
            language: 'json'
        },
        {
            path: 'index.html',
            // [修改] 引用路径改为 /src/index.tsx
            content: '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="UTF-8" />\n<title>Vite + React</title>\n</head>\n<body>\n<div id="root"></div>\n<script type="module" src="/src/index.tsx"></script>\n</body>\n</html>',
            language: 'html'
        },
        {
            path: 'src/index.tsx', // [修改] 移入 src
            content: "import React from 'react'\nimport ReactDOM from 'react-dom/client'\nimport App from './App.tsx'\nimport './index.css'\n\nReactDOM.createRoot(document.getElementById('root')!).render(\n<React.StrictMode>\n<App />\n</React.StrictMode>,\n)",
            language: 'typescript'
        },
        {
            path: 'src/App.tsx', // [修改] 移入 src
            content: "import React, { useState } from 'react';\nimport { Sparkles } from 'lucide-react';\n\nfunction App() {\nconst [count, setCount] = useState(0);\n\nreturn (\n<div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', fontFamily: 'sans-serif', background: '#111', color: '#fff' }}>\n<div style={{ marginBottom: '20px', color: '#a855f7' }}>\n<Sparkles size={48} />\n</div>\n<h1>Hello GeBrain</h1>\n<p>This is a live React preview.</p>\n<button\nonClick={() => setCount(c => c + 1)}\nstyle={{ padding: '10px 20px', fontSize: '16px', borderRadius: '8px', border: 'none', background: '#2563eb', color: 'white', cursor: 'pointer', marginTop: '20px' }}\n>\nCount is {count}\n</button>\n</div>\n);\n}\n\nexport default App;",
            language: 'typescript'
        },
        {
            path: 'src/index.css', // [修改] 移入 src
            content: "body { margin: 0; display: flex; place-items: center; min-width: 320px; min-height: 100vh; background: #111; color: white; }",
            language: 'css'
        }
    ],
    vue: [
        {
            path: 'package.json',
            content: JSON.stringify({
                "name": "vite-vue-starter",
                "private": true,
                "version": "0.0.0",
                "type": "module",
                "scripts": { "dev": "vite", "build": "vite build", "preview": "vite preview" },
                "dependencies": { "vue": "^3.3.4" },
                "devDependencies": { "@vitejs/plugin-vue": "^4.2.3", "vite": "^4.4.5" }
            }, null, 2),
            language: 'json'
        },
        {
            path: 'index.html',
            content: '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8" />\n<title>Vite + Vue</title>\n</head>\n<body>\n<div id="app"></div>\n<script type="module" src="/src/main.ts"></script>\n</body>\n</html>',
            language: 'html'
        },
        {
            path: 'src/main.ts',
            content: "import { createApp } from 'vue'\nimport './style.css'\nimport App from './App.vue'\n\ncreateApp(App).mount('#app')",
            language: 'typescript'
        },
        {
            path: 'src/App.vue',
            content: "<script setup lang=\"ts\">\nimport { ref } from 'vue'\nconst msg = ref('Hello Vue 3 + TypeScript')\nconst count = ref(0)\n</script>\n\n<template>\n  <div class=\"container\">\n    <h1>{{ msg }}</h1>\n    <button @click=\"count++\">Count is: {{ count }}</button>\n  </div>\n</template>\n\n<style scoped>\n.container {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  height: 100vh;\n  font-family: sans-serif;\n}\nbutton {\n  margin-top: 20px;\n  padding: 10px 20px;\n  background: #42b883;\n  border: none;\n  color: white;\n  border-radius: 4px;\n  cursor: pointer;\n}\n</style>",
            language: 'html'
        },
        {
            path: 'src/style.css',
            content: "body { margin: 0; background: #1a1a1a; color: white; }",
            language: 'css'
        }
    ],
    vanilla: [
        {
            path: 'index.html',
            content: '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8" />\n<meta name="viewport" content="width=device-width, initial-scale=1.0" />\n<title>Vanilla JS</title>\n<link rel="stylesheet" href="src/style.css">\n</head>\n<body>\n<div id="app">\n  <h1>Hello Vanilla JS</h1>\n  <button id="counter">Count is 0</button>\n</div>\n<script type="module" src="/src/main.ts"></script>\n</body>\n</html>',
            language: 'html'
        },
        {
            path: 'src/main.ts',
            content: "import './style.css'\n\ndocument.querySelector<HTMLDivElement>('#app')!.innerHTML = `\n  <div>\n    <h1>Hello Vanilla JS!</h1>\n    <div class=\"card\">\n      <button id=\"counter\" type=\"button\">count is 0</button>\n    </div>\n  </div>\n`\n\nlet counter = 0;\nconst element = document.querySelector<HTMLButtonElement>('#counter')!;\nelement.addEventListener('click', () => {\n  counter++;\n  element.innerHTML = `count is ${counter}`\n})",
            language: 'typescript'
        },
        {
            path: 'src/style.css',
            content: "body { margin: 0; display: flex; place-items: center; min-width: 320px; min-height: 100vh; background: #111; color: white; justify-content: center; font-family: sans-serif; } button { padding: 8px 16px; cursor: pointer; }",
            language: 'css'
        }
    ]
};

export const FileWorkspace: React.FC = () => {
    // 1. 保留 useBrain 获取 config (如果后续 Preview 需要用到 config 中的其他信息)
    const { config } = useBrain();

    // File Store Actions
    const files = useFileStore(s => s.files);
    const activeFileId = useFileStore(s => s.activeFileId);
    const setActiveFileId = useFileStore(s => s.setActiveFileId);
    const setFiles = useFileStore(s => s.setFiles);
    const addFile = useFileStore(s => s.addFile);
    const updateFileContent = useFileStore(s => s.updateFileContent);
    const deleteFile = useFileStore(s => s.deleteFile);
    const toggleFileContext = useFileStore(s => s.toggleFileContext);
    const getFileById = useFileStore(s => s.getFileById);

    const uploadInputRef = useRef<HTMLInputElement>(null);
    const [notification, setNotification] = useState<{ message: string, type: 'success' | 'error' } | null>(null);

    // Tab 状态：代码编辑 vs 实时预览
    const [activeTab, setActiveTab] = useState<'code' | 'preview'>('code');

    // Helper to show inline notification
    const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
        setNotification({ message, type });
        setTimeout(() => setNotification(null), 3000);
    };

    const activeFile = getFileById(activeFileId || '') || null;

    // --- Actions ---

    const handleSaveFile = (id: string, content: string) => {
        updateFileContent(id, content);
    };

    const handleToggleContext = (id: string) => {
        toggleFileContext(id);
    };

    const handleCreateFile = (inputPath: string) => {
        if (!inputPath) return;
        const cleanPath = normalizePath(inputPath);
        const fileName = cleanPath.split('/').pop() || cleanPath;

        if (files.some(f => normalizePath(f.path || f.name) === cleanPath)) {
            showNotification("File already exists!", "error");
            return;
        }

        const newFile: VirtualFile = {
            id: crypto.randomUUID(),
            path: cleanPath,
            name: fileName,
            content: '',
            lastModified: Date.now(),
            inContext: true
        };

        addFile(newFile);
        setActiveFileId(newFile.id);
        setActiveTab('code');
    };

    const handleDeleteFile = (id: string) => {
        deleteFile(id);
        if (activeFileId === id) setActiveFileId(null);
    };

    // --- Template Init (支持多种类型) ---
    const handleInitTemplate = (type: 'react' | 'vue' | 'vanilla') => {
        if (files.length > 0) {
            if (!window.confirm(`Overwrite current workspace with ${type} template?`)) return;
        }

        const rawFiles = TEMPLATES[type];
        const templateFiles: VirtualFile[] = rawFiles.map(f => ({
            id: crypto.randomUUID(),
            path: f.path,
            name: f.path.split('/').pop() || f.path,
            language: f.language,
            content: f.content,
            lastModified: Date.now(),
            inContext: true
        }));

        setFiles(templateFiles);

        // 智能选择一个文件作为初始打开文件
        const entryFile = templateFiles.find(f =>
            f.path.endsWith('App.tsx') ||
            f.path.endsWith('App.vue') ||
            f.path.endsWith('main.ts') ||
            f.path === 'index.html'
        );
        setActiveFileId(entryFile?.id || templateFiles[0].id);

        setActiveTab('preview');
        showNotification(`Initialized ${type.toUpperCase()} Template`, "success");
    };

    // --- Import / Export ---
    const handleDownloadWorkspace = async () => {
        if (files.length === 0) {
            showNotification("Workspace is empty", "error");
            return;
        }
        const zip = new JSZip();
        files.forEach(file => {
            zip.file(file.path || file.name, file.content);
        });
        const blob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = "gbrain-workspace.zip";
        a.click();
        URL.revokeObjectURL(url);
    };

    const handleUploadWorkspace = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        try {
            const zip = await JSZip.loadAsync(file);
            const rawFiles: { path: string; content: string }[] = [];
            const promises: Promise<void>[] = [];

            zip.forEach((relativePath: string, zipEntry: any) => {
                promises.push((async () => {
                    if (zipEntry.dir) return;
                    if (relativePath.includes('__MACOSX') || relativePath.startsWith('.')) return;

                    const content = await zipEntry.async('string');
                    if (content.indexOf('\0') === -1) {
                        rawFiles.push({ path: relativePath, content });
                    }
                })());
            });

            await Promise.all(promises);
            const optimizedFiles = optimizeImportedFiles(rawFiles);

            if (optimizedFiles.length > 0) {
                const newVirtualFiles: VirtualFile[] = optimizedFiles.map(f => ({
                    id: crypto.randomUUID(),
                    path: f.path,
                    name: f.path.split('/').pop() || 'untitled',
                    content: f.content,
                    lastModified: Date.now(),
                    language: undefined,
                    inContext: true
                }));

                // 简单的合并策略：覆盖同名，追加新文件
                const merged = [...files];
                newVirtualFiles.forEach(nf => {
                    const idx = merged.findIndex(e => normalizePath(e.path || e.name) === nf.path);
                    if (idx >= 0) {
                        merged[idx] = { ...merged[idx], content: nf.content, lastModified: Date.now() };
                    } else {
                        merged.push(nf);
                    }
                });

                setFiles(merged);
                showNotification(`Imported ${newVirtualFiles.length} files. Structure optimized.`, 'success');
            } else {
                showNotification("No valid files found.", "error");
            }
        } catch (err) {
            showNotification("Failed to read ZIP.", "error");
            console.error(err);
        }
        if (uploadInputRef.current) uploadInputRef.current.value = '';
    };

    // 准备 Preview 数据 (包含自动模板检测)
    const previewData = useMemo(() => {
        if (activeTab !== 'preview') return null;

        // 核心：自动检测模板类型
        const detectedTemplate = detectTemplate(files);

        return {
            files: transformToSandpackFiles(files),
            dependencies: extractDependencies(files),
            template: detectedTemplate // 传给 PreviewPanel
        };
    }, [files, activeTab]);

    return (
        <div className="flex h-full w-full border-r border-slate-800 bg-[#18181b] flex-shrink-0 animate-fadeIn z-10 flex-col">
            {/* Toolbar & Tabs */}
            <div className="h-12 border-b border-slate-800 flex items-center justify-between px-2 bg-[#18181b] shrink-0 gap-2">

                {/* 1. Tab Switcher */}
                <div className="flex bg-slate-900 rounded p-1 gap-1">
                    <button
                        onClick={() => setActiveTab('code')}
                        className={`px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider transition-colors ${activeTab === 'code' ? 'bg-blue-600 text-white shadow' : 'text-slate-500 hover:text-slate-300'
                            }`}
                    >
                        Code
                    </button>
                    <button
                        onClick={() => setActiveTab('preview')}
                        className={`px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider transition-colors ${activeTab === 'preview' ? 'bg-green-600 text-white shadow' : 'text-slate-500 hover:text-slate-300'
                            }`}
                    >
                        Preview
                    </button>
                </div>

                {/* 2. Notification Area */}
                <div className="flex-1 min-w-0 flex justify-center">
                    {notification && (
                        <div className={`text-[10px] font-bold animate-fadeIn truncate px-2 ${notification.type === 'error' ? 'text-red-400' : 'text-green-400'}`}>
                            {notification.message}
                        </div>
                    )}
                </div>

                {/* 3. Action Buttons */}
                <div className="flex items-center gap-2">
                    {/* Template Switcher */}
                    <div className="flex items-center gap-1 bg-slate-900 rounded px-2 h-7 border border-slate-800">
                        <span className="text-[9px] font-bold text-slate-500 mr-1 uppercase">New</span>
                        <button onClick={() => handleInitTemplate('react')} className="text-[10px] font-medium text-blue-400 hover:text-white transition-colors">React</button>
                        <span className="text-slate-700">|</span>
                        <button onClick={() => handleInitTemplate('vue')} className="text-[10px] font-medium text-green-400 hover:text-white transition-colors">Vue</button>
                        <span className="text-slate-700">|</span>
                        <button onClick={() => handleInitTemplate('vanilla')} className="text-[10px] font-medium text-yellow-400 hover:text-white transition-colors">JS</button>
                    </div>

                    <div className="w-px h-4 bg-slate-800 mx-1"></div>

                    <button onClick={() => uploadInputRef.current?.click()} className="p-1.5 text-slate-500 hover:text-blue-400 hover:bg-slate-800 rounded transition-colors" title="Import ZIP">
                        <Icons.Upload />
                    </button>
                    <input type="file" ref={uploadInputRef} className="hidden" accept=".zip" onChange={handleUploadWorkspace} />

                    <button onClick={handleDownloadWorkspace} className="p-1.5 text-slate-500 hover:text-green-400 hover:bg-slate-800 rounded transition-colors" title="Download ZIP">
                        <Icons.Save />
                    </button>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 min-h-0 flex flex-col relative">
                {/* CODE MODE */}
                <div className={`absolute inset-0 flex flex-col transition-opacity duration-300 ${activeTab === 'code' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
                    <div className="h-1/3 min-h-[150px] max-h-[50%] border-b border-slate-800 overflow-hidden flex flex-col">
                        <FileExplorer
                            files={files}
                            onSelectFile={(f) => setActiveFileId(f.id)}
                            onCreateFile={handleCreateFile}
                            onDeleteFile={handleDeleteFile}
                            onToggleContext={handleToggleContext}
                        />
                    </div>
                    <div className="flex-1 min-h-0 flex flex-col">
                        <CodeEditor
                            file={activeFile}
                            onSave={handleSaveFile}
                            onClose={() => setActiveFileId(null)}
                        />
                    </div>
                </div>

                {/* PREVIEW MODE */}
                <div className={`absolute inset-0 bg-[#18181b] flex flex-col transition-opacity duration-300 ${activeTab === 'preview' ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'}`}>
                    {activeTab === 'preview' && (
                        <PreviewPanel />
                    )}
                </div>
            </div>
        </div>
    );
};